import React from "react";

const NoPage = () => {
  return <div>404</div>;
};

export default NoPage;
