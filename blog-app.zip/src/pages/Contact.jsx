import React from "react";

const Contact = () => {
  return <div>Contac</div>;
};

export default Contact;
